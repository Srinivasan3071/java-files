// Animal class (superclass)
class Animal {
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

// Dog class (subclass of Animal)
class Dog extends Animal {
    // Method overriding
    @Override
    void makeSound() {
        super.makeSound(); // Calls the superclass method
        System.out.println("Dog barks"); // Adds subclass-specific behavior
    }

    // Additional method in Dog class
    void fetch() {
        System.out.println("Dog fetches a ball");
    }
}

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.makeSound(); // Output: Animal makes a sound followed by Dog barks
        dog.fetch();     // Output: Dog fetches a ball
    }
}
