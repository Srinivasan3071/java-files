 import java.util.Queue;
import java.util.LinkedList;

public class queue {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        queue.add(10);
        queue.add(20);
        queue.add(30);
       
 System.out.println("Queue elements: " + queue);

        // Remove and display elements from the queue
        System.out.println("Removed element: " + queue.remove());
        System.out.println("Queue after removal: " + queue);
        // Access the element at the front of the queue without removing it
        System.out.println("Element at the front of the queue: " + queue.peek());
          System.out.println("Element at the front of the queue: " + queue);
    }
}
