import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string:");
        String input = sc.nextLine();
        
        // Split the string into words
        String[] words = input.split("\\s+");
        
        // Reverse the array of words
        Collections.reverse(Arrays.asList(words));
        
        // Join the reversed array back into a single string
        String reversedString = String.join(" ", words);
        
        // Print the reversed string
        System.out.println("Reversed string: " + reversedString);
    }
}
