abstract class car{
    abstract void drive();
    abstract void fly();
    void show(){
        System.out.println("hi");
    }
}
class Vehicle extends car{
    void drive(){
        System.out.println("hello");
    }
    void fly(){
        System.out.println("hello");
    }
    
}
public class Main{
    public static void main(String args[]){
        Vehicle obj;
        obj=new Vehicle();
        obj.show();
    }
}