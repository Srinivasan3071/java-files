import java.util.*;

public class Main {
    public static void main(String[] args) {
        HashMap<Integer, String> hm = new HashMap<>();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of entries you want to add: ");
        int a = sc.nextInt();
        for (int i = 0; i < a; i++) {
            System.out.print("set roll number : ");
            int k = sc.nextInt();
            Scanner ss = new Scanner(System.in);
            System.out.print("enter name : ");
            String v = ss.nextLine();
            hm.put(k, v);
        }
        System.out.println(hm);
    }
}
       