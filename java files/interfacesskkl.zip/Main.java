interface a{
    default void show(){
        System.out.println("hi");
    }
}
interface b{
    default void show(){
        System.out.println("hello");
    }
   
}
class c implements a,b{
     public void show()
     {
        a.super.show();
        b.super.show();
    }
    
}
 class Main{
     public static void main(String args[]){
         c obj;
         obj=new c();
         obj.show();
     }
 }