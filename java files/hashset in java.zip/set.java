 import java.util.HashSet;
public class set{
    public static void main(String[] args) {
        HashSet<String> names = new HashSet<>();
        // Add elements to the HashSet
        names.add("Alice");
        names.add("Bob");
        names.add("Alice"); // Duplicate element, will be ignored
       
        for (String name : names) {
            System.out.println(name);
        }
    }
}
