//ArrayIndexOutOfBoundsExceptionExample
public class Main {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3};
        try {
            int number = numbers[5]; // This will throw ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e.getMessage());
        }
        finally{
        System.out.println("Program continues after exception handling.");
        }
    }
}
