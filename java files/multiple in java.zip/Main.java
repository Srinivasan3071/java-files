interface a{
    void fly();
}
class b implements a{
    public void fly(){
        System.out.println("hi");
    } 
}
class Main{
    public void main(String[] args)
    {
        b obj;
        obj=new b();
        b.fly();
    }
}