class Car{
    void drive(){
        System.out.println("this is car");
    }
    
}
class Vehicle extends Car{
    void drive(){
        System.out.println("vehicle");
        }
}
public class Main{
    public static void main(String args[]){
        Vehicle obj;
        obj =new Vehicle();
        obj.drive();
    }
}