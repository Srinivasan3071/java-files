#include<iostream>
#include<string>
using namespace std;
int main()
{
    char x='a';
    if(isalpha(x))
    cout<<"It is an Alphabet\n";
    else
  cout<<"It is not an Alphabet\n";
    
    if(isdigit(x))
    std::cout<<"It is a Digit\n";
    else
   cout<<"It is not a Digit\n";
    
    
    if(isalnum(x))
    cout<<"It is either Alphabet or Numeric\n";
    else
   cout<<"It is not an Alphabet or Numeric\n";
    
    if(islower(x))
    cout<<"It is a Lowercase\n";
    else
    cout<<"It is not a Lowercase\n";
    
    
    if(isupper(x))
    cout<<"It is a Uppercase\n";
    else
   cout<<"It is not a Uppercase\n";
    
    if(isspace(x))
   cout<<"It is a Space\n";
    else
    cout<<"It is not a Space\n";
    
    if(ispunct(x))
    cout<<"It is a Punctuation\n";
    else
  cout<<"It is not a Punctuation\n";
    
    if(isprint(x))
   cout<<"It is a Printable Character\n";
    else
    cout<<"It is not a Printable Character\n";
    
    if(iscntrl(x))
    cout<<"It is a Control Character\n";
    else
  cout<<"It is not a Control Character\n";
    return 0;
}