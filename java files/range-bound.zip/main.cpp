#include <iostream> 
#include <vector>
using namespace std;

int main(){
    // range bound
    vector<int> a({1, 3, 5, 6, 7});
    for(int i : a){
        cout << i << " ";  // Adding a space for better readability
    }
    return 0;
}

