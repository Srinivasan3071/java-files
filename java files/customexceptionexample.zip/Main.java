class MyException extends Exception {
    // Constructor that accepts a message
    public MyException(String message) {
        super(message); // Call the superclass (Exception) constructor with the message
    }
}

public class Main {
    public static void main(String[] args) {
        try {
            // Code that may raise the custom exception
            throw new MyException("This is a custom exception");
        } catch (MyException e) {
            // Catch the custom exception and print its message
            System.out.println("Caught custom exception: " + e.getMessage());
        }
    }
}
