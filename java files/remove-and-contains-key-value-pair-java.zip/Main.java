import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Create a HashMap
        Map<String, Integer> map = new HashMap<>();

        // Add entries
        map.put("Alice", 25);
        map.put("Bob", 30);
        map.put("Charlie", 28);

        // Check if a key exists
        String keyToCheck = "Bob";
        if (map.containsKey(keyToCheck)) {
            System.out.println(keyToCheck + " is present in the map.");
        } else {
            System.out.println(keyToCheck + " is not present in the map.");
        }

        // Remove an entry
        String keyToRemove = "Alice";
        if (map.containsKey(keyToRemove)) {
            int removedValue = map.remove(keyToRemove);
            System.out.println("Removed " + keyToRemove + " from the map. Value: " + removedValue);
        } else {
            System.out.println(keyToRemove + " is not present in the map. Nothing removed.");
        }

        // Print remaining entries
        System.out.println("Remaining entries:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Name: " + entry.getKey() + ", Age: " + entry.getValue());
        }
    }
}
