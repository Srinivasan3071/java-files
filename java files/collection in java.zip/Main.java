
    import java.util.*;
    public class Main {

    public static void main(String[] args) {
        // adding linked list and array list
        Scanner sc=new Scanner(System.in);
        LinkedList<Integer>arr=new LinkedList<>();
        System.out.println("enter size of list");
        int a=sc.nextInt();
        System.out.println("enter linked list elemets ");
        for(int i=0;i<a;i++){
         System.out.print("enter element number "+(i+1)+" :");
            int b=sc.nextInt();
             arr.add(b);
        }
        ArrayList<Integer>arr1=new ArrayList<>();
        System.out.println("now enter array list elemets ");
        for(int i=0;i<a;i++){
            System.out.print("enter element number "+(i+1)+" :");
               int b=sc.nextInt();
                arr1.add(b);
           }
           System.out.println("added linked liste and array list ");  
        ArrayList<Integer>arr2=new ArrayList<>(); 
        for(int i=0;i<a;i++){
            int y=arr.get(i)+arr1.get(i);
          arr2.add(y);
        }
        System.out.println(arr2);
       
    }
}

