#include <iostream>

// Base class Animal
class Animal {
public:
    void speak() {
        std::cout << "Animal speaks" << std::endl;
    }
};

// Base class FlyingObject
class FlyingObject:public Animal {
public:
    void fly() {
        std::cout << "Flying object flies" << std::endl;
    }
};

// Derived class Bird inherits from both Animal and FlyingObject
class Bird :public FlyingObject {
public:
    // Bird can now use methods from both Animal and FlyingObject
};

int main() {
    Bird bird;

    bird.speak(); // Output: Animal speaks
    bird.fly();   // Output: Flying object flies

    return 0;
}

