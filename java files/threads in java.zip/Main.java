class A extends Thread {
    public void run() {
        for (int i = 0; i <= 10; i++) {
            System.out.println("hi");
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                System.out.println("Thread A interrupted: " + e);
            }
        }
    }
}

class B extends Thread {
    public void run() {
        for (int i = 0; i <= 10; i++) {
            System.out.println("hello");
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                System.out.println("Thread B interrupted: " + e);
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        A obj = new A();
        B c = new B();

        
        obj.start();
        c.start();
    }
}
