public class Main {
    public static void main(String[] args) {
        try {
            // code that may raise an exception
            int data = 100 / 0; // This will throw ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException: Division by zero");
        } finally {
            System.out.println("Finally block is always executed");
        }
        
        System.out.println("Rest of the code...");
    }
}
