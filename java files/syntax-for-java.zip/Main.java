 import java.util.*;
 class Main
{
	 static public void main(String[] args ) {
	     Scanner sc=new Scanner(System.in);
	     int my=sc.nextInt();
		System.out.println(my);
	}
	static{
	    System.out.println("hi");
	}
}
