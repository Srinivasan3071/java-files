import java.util.*;
public class Main{
    public static void main(String[] args) {
        // removing duplicate elements
        Scanner sc=new Scanner(System.in);
        LinkedList<Integer>arr=new LinkedList<>();
        System.out.println("enter elements ");
        for(int i=0;i<=3;i++){
        int a=sc.nextInt();
        arr.add(a);   
        }
        HashSet<Integer>hs=new HashSet<>(arr);
        System.out.println(hs);
    }
     }