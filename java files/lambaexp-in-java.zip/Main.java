
// Define the Car interface with a single abstract method fly
interface Car {
    void fly();
}

public class Main {
    public static void main(String[] args) {
        // Using a lambda expression to implement the fly method of the Car interface
        Car obj =() ->System.out.println("flying");
                
            
        
        // Call the fly method
        obj.fly();
    }
    
}
//with interface