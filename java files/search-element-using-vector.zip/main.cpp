#include <iostream> 
#include <vector>
#include<algorithm>
using namespace std;
int main(){
    //seach element using vector
    vector<int> a;
    for(int i=65;i<=90;i++){
        a.push_back(i);
        
    }
    cout<<"enter search :";
    int x;
    cin>>x;
    auto s=find(a.begin(),a.end(),x);
    cout<<*s;
   /* if(*s>0){
        cout<<"yes";
    }
    else{
        cout<<"no";
    }
    */
}