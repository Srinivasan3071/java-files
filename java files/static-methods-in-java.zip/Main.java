class sqr {
    public static int square(int num) {
        return num * num;
    }
}

public class Main {
    public static void main(String[] args) {
        int result = sqr.square(5);
        System.out.println(result); // Outputs 25
    }
}
