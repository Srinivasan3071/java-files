// Base class
class Animal {
    public void sound() {
        System.out.println("Animal makes a sound");
    }
}

// Intermediate derived class
class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Dog barks");
    }
}

// Further derived class
class Puppy extends Dog {
    @Override
    public void sound() {
        System.out.println("Puppy yelps");
    }
}

// Main class to test multilevel inheritance
public class MultilevelInheritance {
    public static void main(String[] args) {
        Puppy myPuppy = new Puppy();
        myPuppy.sound(); // Output: Puppy yelps
    }
}
