/*In C++, access specifiers determine the accessibility of the members of a class. 
There are three main access specifiers: public, protected, and private. 
These specifiers control how and where the members (variables and functions) of the class can be accessed.
1.Public:

Members declared as public are accessible from outside the class.
These members can be accessed directly using the object of the class.

2.Private:
Members declared as private are accessible only within the class itself.
They cannot be accessed directly from outside the class or in derived classes.
*/
#include <iostream>
using namespace std;

class MyClass {
  public:    // Public access specifier
    int x;   // Public attribute
  private:   // Private access specifier
    int y;   // Private attribute
};

int main() {
  MyClass myObj;
  myObj.x = 25;  // Allowed (x is public)
  myObj.y = 50;  // Not allowed (y is private)
  return 0;
}
