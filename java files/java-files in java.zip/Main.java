import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // Creating a File object
            File file = new File("example.txt");
            
            // Check if the file already exists, if not, create a new file
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
            
            // Writing to the file using FileWriter
            FileWriter writer = new FileWriter(file);
            writer.write("Hello, this is an example of file handling in Java.\n");
            writer.write("This file is written using FileWriter.\n");
            writer.close();
            System.out.println("Successfully wrote to the file.");
            
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
