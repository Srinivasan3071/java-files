#include <iostream>
#include <fstream>
#include <stdexcept>
/*#include <iostream>: Includes the standard input-output stream library, 
allowing the use of std::cout and std::cerr.
#include <fstream>: Includes the file stream library, providing classes for 
file operations (std::ofstream and std::ifstream).
#include <stdexcept>: Includes standard exception classes like std::runtime_error.*/
void writeFile(const std::string& filename) {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        throw std::runtime_error("Unable to open file for writing");
    }
    outFile << "Hello, World!" << std::endl;
}
/*void writeFile(const std::string& filename): Declares a function to write to a file.
std::ofstream outFile(filename): Creates an ofstream object named outFile and attempts to 
open the specified file for writing.
if (!outFile.is_open()): Checks if the file was successfully opened. If not, it throws a std::
runtime_error exception with an appropriate error message.
outFile << "Hello, World!" << std::endl;: Writes the string "Hello, World!" to the file followed by a newline character.*/
void readFile(const std::string& filename) {
    std::ifstream inFile(filename);
    if (!inFile.is_open()) {
        throw std::runtime_error("Unable to open file for reading");
    }
    std::string line;
    while (getline(inFile, line)) {
        std::cout << line << std::endl;
    }
}
/*void readFile(const std::string& filename): Declares a function to read from a file.
std::ifstream inFile(filename): Creates an ifstream object named inFile and attempts to
open the specified file for reading.
if (!inFile.is_open()): Checks if the file was successfully opened. If not, it throws a 
std::runtime_error exception with an appropriate error message.
while (getline(inFile, line)): Reads lines from the file into the line variable until the end of the file is reached.
std::cout << line << std::endl;: Outputs each line read from the file to the console.*/
 int main() {
    std::string filename = "example.txt";
    try {
        writeFile(filename);
        readFile(filename);
    } catch (const std::runtime_error& e) {
        std::cerr << "Runtime error: " << e.what() << std::endl;
    } catch (...) {
        std::cerr << "An unknown error occurred!" << std::endl;
    }
    return 0;
}
/*int main(): The main function where the program execution begins.
std::string filename = "example.txt";: 
Declares a string variable filename and initializes it with the name of the file to be used.
try: Begins a try block to handle exceptions.
writeFile(filename): Calls the writeFile function to write to the file.
readFile(filename): Calls the readFile function to read from the file.
catch (const std::runtime_error& e): Catches exceptions of type 
std::runtime_error and outputs an error message to std::cerr.
std::cerr << "Runtime error: " << e.what() << std::endl;: Outputs the exception message.
catch (...): Catches any other types of exceptions and outputs a generic error message to std::cerr.*/
