interface Car {
    int i = 10; 
    void fly(); 
}

public class Main {
    public static void main(String[] args) {
        
        Car obj = new Car() {
            public void fly() {
                System.out.println("flying");
            }
        };

       
        obj.fly();
    }
}
